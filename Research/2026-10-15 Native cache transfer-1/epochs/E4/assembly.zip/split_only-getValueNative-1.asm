?getValueNative@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@34@@Z PROC ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::getValueNative, COMDAT

; 479  :     {

$LN268:
	mov	QWORD PTR [rsp+32], rbx
	push	rdi
	sub	rsp, 32					; 00000020H
	mov	rdi, rdx
	mov	rbx, rcx

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	edx, DWORD PTR [rdx]
	mov	eax, edx
	and	eax, -8
	cmp	eax, DWORD PTR [rcx+24]
	jne	SHORT $LN250@getValueNa
	mov	ecx, DWORD PTR [rdi+4]
	mov	eax, ecx
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+28]
	jne	SHORT $LN250@getValueNa
	mov	r8d, DWORD PTR [rdi+8]
	mov	eax, r8d
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+32]
	jne	SHORT $LN250@getValueNa
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	and	ecx, 7
	mov	eax, edx
	and	eax, 7
	and	r8d, 7
	shl	eax, 3
	or	ecx, eax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 491  :                     return &(LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)]);

	mov	rax, QWORD PTR [rbx+16]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	shl	ecx, 3
	or	ecx, r8d
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 491  :                     return &(LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)]);

	lea	rax, QWORD PTR [rax+rcx*2]
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	$LN179@getValueNa
$LN250@getValueNa:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	and	edx, -128				; ffffffffffffff80H
	cmp	edx, DWORD PTR [rbx+36]
	jne	SHORT $LN76@getValueNa
	mov	eax, DWORD PTR [rdi+4]
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+40]
	jne	SHORT $LN76@getValueNa
	mov	eax, DWORD PTR [rdi+8]
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+44]
	jne	SHORT $LN76@getValueNa

; 496  :                     return &(node->getValueAndCache(xyz, *this));

	mov	rcx, QWORD PTR [rbx+80]
	mov	r8, rbx
	mov	rdx, rdi
	call	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	$LN179@getValueNa
$LN76@getValueNa:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	eax, DWORD PTR [rdi]
	and	eax, -4096				; fffffffffffff000H
	mov	QWORD PTR [rsp+64], r14
	cmp	eax, DWORD PTR [rbx+48]
	jne	SHORT $LN132@getValueNa
	mov	eax, DWORD PTR [rdi+4]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+52]
	jne	SHORT $LN132@getValueNa
	mov	eax, DWORD PTR [rdi+8]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+56]
	jne	SHORT $LN132@getValueNa

; 494  :                     auto node = mNodes.template get<Idx>();

	mov	rcx, QWORD PTR [rbx+72]
	lea	r14, QWORD PTR [rbx+72]

; 496  :                     return &(node->getValueAndCache(xyz, *this));

	mov	r8, rbx
	mov	rdx, rdi
	call	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	SHORT $LN264@getValueNa
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 496  :                     return &(node->getValueAndCache(xyz, *this));

	jmp	SHORT $LN125@getValueNa
$LN132@getValueNa:

; 480  :         // Don't use evalFirstCached as we don't access the node when
; 481  :         // IsLeafAndBypassLeafAPI<NodeType> is true.
; 482  :         return *this->evalFirstIndex([&](const auto Idx) -> const ValueType*
; 483  :             {
; 484  :                 using NodeType = typename NodeLevelList::template Get<Idx>;
; 485  :                 // If not cached return a nullptr. Note that this operator is
; 486  :                 // guaranteed to return a value as the last node in the chain
; 487  :                 // is a RootNode and isHashed always returns true for this case
; 488  :                 if (!this->isHashed<NodeType>(xyz)) return nullptr;

	lea	r14, QWORD PTR [rbx+72]
$LN125@getValueNa:
	mov	QWORD PTR [rsp+56], rsi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1771 :     MapCIter iter = this->findCoord(xyz);

	lea	rdx, QWORD PTR iter$4[rsp]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 494  :                     auto node = mNodes.template get<Idx>();

	mov	rsi, QWORD PTR [rbx+64]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1771 :     MapCIter iter = this->findCoord(xyz);

	mov	r8, rdi
	mov	rcx, rsi
	call	?findCoord@?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@AEBA?AV?$_Tree_const_iterator@V?$_Tree_val@U?$_Tree_simple_types@U?$pair@$$CBVCoord@math@v13_0@openvdb@@UNodeStruct@?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@34@@std@@@std@@@std@@@std@@AEBVCoord@math@34@@Z ; openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> >::findCoord

; 1772 :     if (iter == mTable.end()) return mBackground;

	mov	rax, QWORD PTR iter$4[rsp]
	cmp	rax, QWORD PTR [rsi]
	jne	SHORT $LN180@getValueNa
	lea	rax, QWORD PTR [rsi+16]
	jmp	SHORT $LN265@getValueNa
$LN180@getValueNa:

; 147  :         bool isChild() const { return child != nullptr; }

	mov	rdx, QWORD PTR [rax+48]

; 1773 :     if (isChild(iter)) {

	test	rdx, rdx
	je	SHORT $LN181@getValueNa
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	ecx, DWORD PTR [rdi+8]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1775 :         return getChild(iter).getValueAndCache(xyz, acc);

	mov	r8, rbx
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1009 :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	movq	xmm0, QWORD PTR [rdi]
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	and	ecx, -4096				; fffffffffffff000H
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1009 :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	andps	xmm0, XMMWORD PTR __xmm@fffff000fffff000fffff000fffff000
	movq	QWORD PTR [rbx+48], xmm0
	mov	DWORD PTR [rbx+56], ecx

; 1010 :             mNodes.template get<Idx>() = const_cast<NodeT*>(node);

	mov	QWORD PTR [r14], rdx
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1775 :         return getChild(iter).getValueAndCache(xyz, acc);

	mov	rdx, rdi
	mov	rcx, QWORD PTR [rax+48]
	call	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
	jmp	SHORT $LN265@getValueNa
$LN181@getValueNa:

; 168  :     static const Tile&      getTile(const MapCIter& i) { return i->second.tile; }

	add	rax, 56					; 00000038H
$LN265@getValueNa:
	mov	rsi, QWORD PTR [rsp+56]
$LN264@getValueNa:
	mov	r14, QWORD PTR [rsp+64]
$LN179@getValueNa:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 499  :     }

	mov	rbx, QWORD PTR [rsp+72]
	add	rsp, 32					; 00000020H
	pop	rdi
	ret	0
?getValueNative@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@34@@Z ENDP ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::getValueNative
