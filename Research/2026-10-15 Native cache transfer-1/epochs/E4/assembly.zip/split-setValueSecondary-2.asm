?setValueSecondary@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@34@AEBG@Z PROC ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::setValueSecondary, COMDAT

; 600  :     {

$LN339:
	mov	QWORD PTR [rsp+24], rbx
	push	rsi
	push	rdi
	push	r14
	sub	rsp, 32					; 00000020H

; 1114 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	r10d, DWORD PTR [rdx]

; 600  :     {

	mov	rbx, rcx

; 1114 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	r11d, DWORD PTR [rdx+8]
	mov	eax, r10d
	mov	r9d, DWORD PTR [rdx+4]
	and	eax, 24

; 600  :     {

	mov	rdi, rdx

; 1114 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	ecx, r11d
	shr	rcx, 2

; 600  :     {

	mov	r14, r8

; 1114 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	and	ecx, 6
	lea	edx, DWORD PTR [rax+rax]
	mov	eax, r9d
	and	eax, 24
	or	rcx, rax
	shr	rcx, 1
	or	rcx, rdx

; 601  : #ifdef EXPERIMENT_LEAF_CACHE
; 602  :         const auto leaf = mSecondaryLeaves[secondarySlot(xyz)];

	mov	rsi, QWORD PTR [rbx+rcx*8+24]

; 603  :         if (leaf && leaf->origin() == (xyz & ~Coord::ValueType(LeafNodeT::DIM-1))) {

	test	rsi, rsi
	je	$LN322@setValueSe
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	eax, r10d
	and	eax, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rsi+80], eax
	jne	$LN322@setValueSe

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	ecx, r9d
	and	ecx, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rsi+84], ecx
	jne	$LN322@setValueSe

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	edx, r11d
	and	edx, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rsi+88], edx
	jne	$LN322@setValueSe
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1009 :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	mov	DWORD PTR [rbx+536], eax
	mov	DWORD PTR [rbx+540], ecx
	mov	DWORD PTR [rbx+544], edx

; 1010 :             mNodes.template get<Idx>() = const_cast<NodeT*>(node);

	mov	QWORD PTR [rbx+600], rsi

; 1114 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	eax, DWORD PTR [rdi+4]
	mov	ecx, DWORD PTR [rdi+8]
	and	eax, 24
	shr	rcx, 2
	and	ecx, 6
	or	rcx, rax
	mov	eax, DWORD PTR [rdi]
	and	eax, 24
	shr	rcx, 1
	add	eax, eax
	or	rcx, rax

; 1013 :                 mSecondaryLeaves[secondarySlot(xyz)] = node;

	mov	QWORD PTR [rbx+rcx*8+24], rsi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafBuffer.h

; 370  :     if (mData == nullptr) {

	mov	rdx, QWORD PTR [rsi]
	test	rdx, rdx
	jne	SHORT $LN317@setValueSe

; 371  :         LeafBuffer* self = const_cast<LeafBuffer*>(this);
; 372  : #ifdef OPENVDB_USE_DELAYED_LOADING
; 373  :         // This lock will be contended at most once.
; 374  :         tbb::spin_mutex::scoped_lock lock(self->mMutex);
; 375  : #endif
; 376  :         if (mData == nullptr) self->mData = new ValueType[SIZE];

	mov	ecx, 1024				; 00000400H
	call	??_U@YAPEAX_K@Z				; operator new[]
	mov	rdx, rax
	mov	QWORD PTR [rsi], rax
$LN317@setValueSe:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1016 :                 LeafCacheT::setBuffer(node->buffer().data());

	mov	QWORD PTR [rbx+16], rdx
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	mov	ecx, DWORD PTR [rdi]
	mov	eax, DWORD PTR [rdi+4]
	and	ecx, 7
	and	eax, 7
	lea	ecx, DWORD PTR [rax+rcx*8]
	mov	eax, DWORD PTR [rdi+8]
	and	eax, 7
	lea	r8d, DWORD PTR [rax+rcx*8]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 588  :         const_cast<ValueType&>(LeafCacheT::buffer()[offset]) = value;

	movzx	eax, WORD PTR [r14]
	mov	WORD PTR [rdx+r8*2], ax
; File D:\source\openvdb\openvdb\openvdb\util\NodeMasks.h

; 455  :         mWords[n >> 6] |=  Word(1) << (n & 63);

	mov	edx, r8d
	mov	rcx, QWORD PTR [rbx+600]
	and	r8d, 63					; 0000003fH
	shr	rdx, 6
	mov	rax, QWORD PTR [rcx+rdx*8+16]
	bts	rax, r8
	mov	QWORD PTR [rcx+rdx*8+16], rax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 610  :     }

	mov	rbx, QWORD PTR [rsp+80]
	add	rsp, 32					; 00000020H
	pop	r14
	pop	rdi
	pop	rsi
	ret	0
$LN322@setValueSe:

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	eax, r10d
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+536]
	jne	SHORT $LN137@setValueSe
	mov	eax, r9d
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+540]
	jne	SHORT $LN137@setValueSe
	mov	eax, r11d
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+544]
	jne	SHORT $LN137@setValueSe

; 624  :                     const_cast<ValueType&>(LeafCacheT::buffer()[offset]) = value;

	mov	rcx, QWORD PTR [rbx+16]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	and	r10d, 7
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 531  :         if (pred(Idx)) op(std::get<Idx>(tup));

	mov	r8, QWORD PTR [rbx+600]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	and	r9d, 7
	and	r11d, 7
	lea	eax, DWORD PTR [r9+r10*8]
	lea	edx, DWORD PTR [r11+rax*8]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 624  :                     const_cast<ValueType&>(LeafCacheT::buffer()[offset]) = value;

	movzx	eax, WORD PTR [r14]
	mov	WORD PTR [rcx+rdx*2], ax
; File D:\source\openvdb\openvdb\openvdb\util\NodeMasks.h

; 455  :         mWords[n >> 6] |=  Word(1) << (n & 63);

	mov	ecx, edx
	shr	rcx, 6
	and	edx, 63					; 0000003fH
	mov	rax, QWORD PTR [r8+rcx*8+16]
	bts	rax, rdx
	mov	QWORD PTR [r8+rcx*8+16], rax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 610  :     }

	mov	rbx, QWORD PTR [rsp+80]
	add	rsp, 32					; 00000020H
	pop	r14
	pop	rdi
	pop	rsi
	ret	0
$LN137@setValueSe:

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	eax, r10d
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+548]
	jne	SHORT $LN209@setValueSe
	mov	eax, r9d
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+552]
	jne	SHORT $LN209@setValueSe
	mov	eax, r11d
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+556]
	jne	SHORT $LN209@setValueSe

; 639  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	mov	rcx, QWORD PTR [rbx+592]
	mov	r9, rbx
	mov	rdx, rdi

; 610  :     }

	mov	rbx, QWORD PTR [rsp+80]
	add	rsp, 32					; 00000020H
	pop	r14
	pop	rdi
	pop	rsi

; 639  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	jmp	??$setValueAndCache@V?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@23@AEBGAEAV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>::setValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > >
$LN209@setValueSe:

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	and	r10d, -4096				; fffffffffffff000H
	cmp	r10d, DWORD PTR [rbx+560]
	jne	SHORT $LN260@setValueSe
	and	r9d, -4096				; fffffffffffff000H
	cmp	r9d, DWORD PTR [rbx+564]
	jne	SHORT $LN260@setValueSe
	and	r11d, -4096				; fffffffffffff000H
	cmp	r11d, DWORD PTR [rbx+568]
	jne	SHORT $LN260@setValueSe

; 639  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	mov	rcx, QWORD PTR [rbx+584]
	mov	r9, rbx
	mov	rdx, rdi

; 610  :     }

	mov	rbx, QWORD PTR [rsp+80]
	add	rsp, 32					; 00000020H
	pop	r14
	pop	rdi
	pop	rsi

; 639  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	jmp	??$setValueAndCache@V?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@23@AEBGAEAV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5>::setValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > >
$LN260@setValueSe:
	mov	rcx, QWORD PTR [rbx+576]
	mov	r9, rbx
	mov	rdx, rdi

; 610  :     }

	mov	rbx, QWORD PTR [rsp+80]
	add	rsp, 32					; 00000020H
	pop	r14
	pop	rdi
	pop	rsi

; 639  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	jmp	??$setValueAndCache@V?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@23@AEBGAEAV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> >::setValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > >
?setValueSecondary@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@34@AEBG@Z ENDP ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::setValueSecondary
