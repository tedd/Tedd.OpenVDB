?getValueSecondary@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@34@@Z PROC ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::getValueSecondary, COMDAT

; 465  :     {

$LN317:
	mov	QWORD PTR [rsp+24], rbx
	mov	QWORD PTR [rsp+32], rsi
	push	rdi
	sub	rsp, 64					; 00000040H
	mov	rbx, rcx
	mov	rdi, rdx

; 1114 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	edx, DWORD PTR [rdx+8]
	mov	ecx, edx
	shr	rcx, 2
	and	ecx, 6
	mov	r9d, DWORD PTR [rdi]
	mov	eax, r9d
	mov	r10d, DWORD PTR [rdi+4]
	and	eax, 24
	lea	r8d, DWORD PTR [rax+rax]
	mov	eax, r10d
	and	eax, 24
	or	rcx, rax
	shr	rcx, 1
	or	rcx, r8

; 466  : #ifdef EXPERIMENT_LEAF_CACHE
; 467  :         const auto leaf = mSecondaryLeaves[secondarySlot(xyz)];

	mov	rsi, QWORD PTR [rbx+rcx*8+24]

; 468  :         if (leaf && leaf->origin() == (xyz & ~Coord::ValueType(LeafNodeT::DIM-1))) {

	test	rsi, rsi
	je	$LN299@getValueSe
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	eax, r9d
	and	eax, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rsi+80], eax
	jne	$LN299@getValueSe

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	ecx, r10d
	and	ecx, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rsi+84], ecx
	jne	$LN299@getValueSe

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	r8d, edx
	and	r8d, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rsi+88], r8d
	jne	$LN299@getValueSe
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1009 :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	mov	DWORD PTR [rbx+536], eax
	mov	DWORD PTR [rbx+540], ecx
	mov	DWORD PTR [rbx+544], r8d

; 1010 :             mNodes.template get<Idx>() = const_cast<NodeT*>(node);

	mov	QWORD PTR [rbx+600], rsi

; 1114 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	eax, DWORD PTR [rdi+4]
	mov	ecx, DWORD PTR [rdi+8]
	and	eax, 24
	shr	rcx, 2
	and	ecx, 6
	or	rcx, rax
	mov	eax, DWORD PTR [rdi]
	and	eax, 24
	shr	rcx, 1
	add	eax, eax
	or	rcx, rax

; 1013 :                 mSecondaryLeaves[secondarySlot(xyz)] = node;

	mov	QWORD PTR [rbx+rcx*8+24], rsi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafBuffer.h

; 370  :     if (mData == nullptr) {

	mov	rdx, QWORD PTR [rsi]
	test	rdx, rdx
	jne	SHORT $LN294@getValueSe

; 371  :         LeafBuffer* self = const_cast<LeafBuffer*>(this);
; 372  : #ifdef OPENVDB_USE_DELAYED_LOADING
; 373  :         // This lock will be contended at most once.
; 374  :         tbb::spin_mutex::scoped_lock lock(self->mMutex);
; 375  : #endif
; 376  :         if (mData == nullptr) self->mData = new ValueType[SIZE];

	mov	ecx, 1024				; 00000400H
	call	??_U@YAPEAX_K@Z				; operator new[]
	mov	rdx, rax
	mov	QWORD PTR [rsi], rax
$LN294@getValueSe:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1016 :                 LeafCacheT::setBuffer(node->buffer().data());

	mov	QWORD PTR [rbx+16], rdx
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	mov	eax, DWORD PTR [rdi]
	mov	ecx, DWORD PTR [rdi+4]
	and	eax, 7
	shl	eax, 3
	and	ecx, 7
	or	ecx, eax
	mov	eax, DWORD PTR [rdi+8]
	and	eax, 7
	shl	ecx, 3
	or	ecx, eax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 470  :             return LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)];

	lea	rax, QWORD PTR [rdx+rcx*2]

; 474  :     }

	mov	rbx, QWORD PTR [rsp+96]
	mov	rsi, QWORD PTR [rsp+104]
	add	rsp, 64					; 00000040H
	pop	rdi
	ret	0
$LN299@getValueSe:

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	eax, r9d
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+536]
	jne	SHORT $LN300@getValueSe
	mov	eax, r10d
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+540]
	jne	SHORT $LN300@getValueSe
	mov	eax, edx
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+544]
	jne	SHORT $LN300@getValueSe
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	mov	ecx, r9d
	and	r10d, 7
	and	ecx, 7
	mov	eax, edx
	shl	ecx, 3
	and	eax, 7
	or	ecx, r10d
	shl	ecx, 3
	or	ecx, eax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 491  :                     return &(LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)]);

	mov	rax, QWORD PTR [rbx+16]
	lea	rax, QWORD PTR [rax+rcx*2]
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	$LN241@getValueSe
$LN300@getValueSe:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	and	r9d, -128				; ffffffffffffff80H
	cmp	r9d, DWORD PTR [rbx+548]
	jne	SHORT $LN193@getValueSe
	mov	eax, DWORD PTR [rdi+4]
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+552]
	jne	SHORT $LN193@getValueSe
	and	edx, -128				; ffffffffffffff80H
	cmp	edx, DWORD PTR [rbx+556]
	jne	SHORT $LN193@getValueSe

; 496  :                     return &(node->getValueAndCache(xyz, *this));

	mov	rcx, QWORD PTR [rbx+592]
	mov	r8, rbx
	mov	rdx, rdi
	call	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	SHORT $LN241@getValueSe
$LN193@getValueSe:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	eax, DWORD PTR [rdi]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+560]
	jne	SHORT $LN242@getValueSe
	mov	eax, DWORD PTR [rdi+4]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+564]
	jne	SHORT $LN242@getValueSe
	mov	eax, DWORD PTR [rdi+8]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+568]
	jne	SHORT $LN242@getValueSe

; 496  :                     return &(node->getValueAndCache(xyz, *this));

	mov	rcx, QWORD PTR [rbx+584]
	mov	r8, rbx
	mov	rdx, rdi
	call	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	SHORT $LN241@getValueSe
$LN242@getValueSe:
	movzx	edx, BYTE PTR $T4[rsp]
	lea	rcx, QWORD PTR $T5[rsp]

; 517  :         return TSEvalFirstIndex<OpT, RetT, Iter+1, End>(op, def);

	mov	QWORD PTR $T5[rsp], rbx
	mov	QWORD PTR $T5[rsp+8], rdi

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	call	??$?RU?$integral_constant@_K$02@std@@@<lambda_e4649fcf69ede42423c785e8d6f0e9d1>@@QEBAPEBGU?$integral_constant@_K$02@std@@@Z ; <lambda_e4649fcf69ede42423c785e8d6f0e9d1>::operator()<std::integral_constant<unsigned __int64,3> >
$LN241@getValueSe:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 474  :     }

	mov	rbx, QWORD PTR [rsp+96]
	mov	rsi, QWORD PTR [rsp+104]
	add	rsp, 64					; 00000040H
	pop	rdi
	ret	0
?getValueSecondary@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@34@@Z ENDP ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::getValueSecondary
