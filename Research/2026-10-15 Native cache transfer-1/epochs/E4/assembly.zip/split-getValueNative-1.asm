?getValueNative@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@34@@Z PROC ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::getValueNative, COMDAT

; 479  :     {

$LN192:
	mov	QWORD PTR [rsp+16], rbx
	push	rdi
	sub	rsp, 48					; 00000030H
	mov	rdi, rdx
	mov	rbx, rcx

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	edx, DWORD PTR [rdx]
	mov	eax, edx
	and	eax, -8
	cmp	eax, DWORD PTR [rcx+536]
	jne	SHORT $LN179@getValueNa
	mov	ecx, DWORD PTR [rdi+4]
	mov	eax, ecx
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+540]
	jne	SHORT $LN179@getValueNa
	mov	r8d, DWORD PTR [rdi+8]
	mov	eax, r8d
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+544]
	jne	SHORT $LN179@getValueNa
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	and	ecx, 7
	mov	eax, edx
	and	eax, 7
	and	r8d, 7
	shl	eax, 3
	or	ecx, eax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 491  :                     return &(LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)]);

	mov	rax, QWORD PTR [rbx+16]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	shl	ecx, 3
	or	ecx, r8d
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 491  :                     return &(LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)]);

	lea	rax, QWORD PTR [rax+rcx*2]
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	$LN124@getValueNa
$LN179@getValueNa:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	and	edx, -128				; ffffffffffffff80H
	cmp	edx, DWORD PTR [rbx+548]
	jne	SHORT $LN76@getValueNa
	mov	eax, DWORD PTR [rdi+4]
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+552]
	jne	SHORT $LN76@getValueNa
	mov	eax, DWORD PTR [rdi+8]
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rbx+556]
	jne	SHORT $LN76@getValueNa

; 496  :                     return &(node->getValueAndCache(xyz, *this));

	mov	rcx, QWORD PTR [rbx+592]
	mov	r8, rbx
	mov	rdx, rdi
	call	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	SHORT $LN124@getValueNa
$LN76@getValueNa:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1032 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	eax, DWORD PTR [rdi]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+560]
	jne	SHORT $LN125@getValueNa
	mov	eax, DWORD PTR [rdi+4]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+564]
	jne	SHORT $LN125@getValueNa
	mov	eax, DWORD PTR [rdi+8]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rbx+568]
	jne	SHORT $LN125@getValueNa

; 496  :                     return &(node->getValueAndCache(xyz, *this));

	mov	rcx, QWORD PTR [rbx+584]
	mov	r8, rbx
	mov	rdx, rdi
	call	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	test	rax, rax
	jne	SHORT $LN124@getValueNa
$LN125@getValueNa:
	movzx	edx, BYTE PTR $T5[rsp]
	lea	rcx, QWORD PTR $T4[rsp]

; 517  :         return TSEvalFirstIndex<OpT, RetT, Iter+1, End>(op, def);

	mov	QWORD PTR $T4[rsp], rbx
	mov	QWORD PTR $T4[rsp+8], rdi

; 516  :         if (auto ret = op(std::integral_constant<std::size_t, Iter>())) return ret;

	call	??$?RU?$integral_constant@_K$02@std@@@<lambda_e4649fcf69ede42423c785e8d6f0e9d1>@@QEBAPEBGU?$integral_constant@_K$02@std@@@Z ; <lambda_e4649fcf69ede42423c785e8d6f0e9d1>::operator()<std::integral_constant<unsigned __int64,3> >
$LN124@getValueNa:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 499  :     }

	mov	rbx, QWORD PTR [rsp+72]
	add	rsp, 48					; 00000030H
	pop	rdi
	ret	0
?getValueNative@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@34@@Z ENDP ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::getValueNative
