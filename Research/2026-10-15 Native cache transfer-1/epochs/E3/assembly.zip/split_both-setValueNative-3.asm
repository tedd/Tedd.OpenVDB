?setValueNative@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@34@AEBG@Z PROC ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::setValueNative, COMDAT

; 611  :     {

$LN211:
	push	rbx

; 1028 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	r9d, DWORD PTR [rdx]
	mov	eax, r9d
	and	eax, -8
	cmp	eax, DWORD PTR [rcx+536]
	jne	SHORT $LN14@setValueNa
	mov	r10d, DWORD PTR [rdx+4]
	mov	eax, r10d
	and	eax, -8
	cmp	eax, DWORD PTR [rcx+540]
	jne	SHORT $LN14@setValueNa
	mov	ebx, DWORD PTR [rdx+8]
	mov	eax, ebx
	and	eax, -8
	cmp	eax, DWORD PTR [rcx+544]
	jne	SHORT $LN14@setValueNa
; File D:\source\openvdb\openvdb\openvdb\TypeList.h

; 531  :         if (pred(Idx)) op(std::get<Idx>(tup));

	mov	r11, QWORD PTR [rcx+600]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	and	r9d, 7
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 620  :                     const_cast<ValueType&>(LeafCacheT::buffer()[offset]) = value;

	mov	rcx, QWORD PTR [rcx+16]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	and	r10d, 7
	and	ebx, 7
	lea	eax, DWORD PTR [r10+r9*8]
	lea	edx, DWORD PTR [rbx+rax*8]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 620  :                     const_cast<ValueType&>(LeafCacheT::buffer()[offset]) = value;

	movzx	eax, WORD PTR [r8]
	mov	WORD PTR [rcx+rdx*2], ax

; 621  : #ifdef EXPERIMENT_DENSE_MASK
; 622  :                     // This experiment targets ordinary leaves with at least 64 voxels.
; 623  :                     // Smaller leaves retain their original mask API and behavior.
; 624  :                     if constexpr (NodeType::LOG2DIM >= 2) {
; 625  :                         if (node->getValueMask().template getWord<Index64>(offset >> 6) != ~Index64(0))

	mov	ecx, edx
	shr	rcx, 6
	cmp	QWORD PTR [r11+rcx*8+16], -1
	je	$LN192@setValueNa
; File D:\source\openvdb\openvdb\openvdb\util\NodeMasks.h

; 455  :         mWords[n >> 6] |=  Word(1) << (n & 63);

	mov	rax, QWORD PTR [r11+rcx*8+16]
	and	edx, 63					; 0000003fH
	bts	rax, rdx
	mov	QWORD PTR [r11+rcx*8+16], rax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 638  :     }

	pop	rbx
	ret	0
$LN14@setValueNa:

; 1028 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	eax, r9d
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rcx+548]
	jne	SHORT $LN89@setValueNa
	mov	eax, DWORD PTR [rdx+4]
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rcx+552]
	jne	SHORT $LN89@setValueNa
	mov	eax, DWORD PTR [rdx+8]
	and	eax, -128				; ffffffffffffff80H
	cmp	eax, DWORD PTR [rcx+556]
	jne	SHORT $LN89@setValueNa

; 635  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	mov	r9, rcx
	mov	rcx, QWORD PTR [rcx+592]

; 638  :     }

	pop	rbx

; 635  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	jmp	??$setValueAndCache@V?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@23@AEBGAEAV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>::setValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > >
$LN89@setValueNa:

; 1028 :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	and	r9d, -4096				; fffffffffffff000H
	cmp	r9d, DWORD PTR [rcx+560]
	jne	SHORT $LN140@setValueNa
	mov	eax, DWORD PTR [rdx+4]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rcx+564]
	jne	SHORT $LN140@setValueNa
	mov	eax, DWORD PTR [rdx+8]
	and	eax, -4096				; fffffffffffff000H
	cmp	eax, DWORD PTR [rcx+568]
	jne	SHORT $LN140@setValueNa

; 635  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	mov	r9, rcx
	mov	rcx, QWORD PTR [rcx+584]

; 638  :     }

	pop	rbx

; 635  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	jmp	??$setValueAndCache@V?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@23@AEBGAEAV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5>::setValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > >
$LN140@setValueNa:
	mov	r9, rcx
	mov	rcx, QWORD PTR [rcx+576]

; 638  :     }

	pop	rbx

; 635  :                     const_cast<NodeType*>(node)->setValueAndCache(xyz, value, *this);

	jmp	??$setValueAndCache@V?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@23@AEBGAEAV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> >::setValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > >
$LN192@setValueNa:

; 638  :     }

	pop	rbx
	ret	0
?setValueNative@?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@QEAAXAEBVCoord@math@34@AEBG@Z ENDP ; openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> >::setValueNative
