??$?RU?$integral_constant@_K$02@std@@@<lambda_e4649fcf69ede42423c785e8d6f0e9d1>@@QEBAPEBGU?$integral_constant@_K$02@std@@@Z PROC ; <lambda_e4649fcf69ede42423c785e8d6f0e9d1>::operator()<std::integral_constant<unsigned __int64,3> >, COMDAT

; 496  :             });

$LN76:
	mov	QWORD PTR [rsp+16], rbx
	mov	QWORD PTR [rsp+24], rsi
	push	rdi
	sub	rsp, 32					; 00000020H

; 492  :                     auto node = mNodes.template get<Idx>();

	mov	rdi, QWORD PTR [rcx]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1771 :     MapCIter iter = this->findCoord(xyz);

	lea	rdx, QWORD PTR iter$1[rsp]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 494  :                     return &(node->getValueAndCache(xyz, *this));

	mov	rsi, QWORD PTR [rcx+8]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1771 :     MapCIter iter = this->findCoord(xyz);

	mov	r8, rsi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 492  :                     auto node = mNodes.template get<Idx>();

	mov	rbx, QWORD PTR [rdi+576]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1771 :     MapCIter iter = this->findCoord(xyz);

	mov	rcx, rbx
	call	?findCoord@?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@AEBA?AV?$_Tree_const_iterator@V?$_Tree_val@U?$_Tree_simple_types@U?$pair@$$CBVCoord@math@v13_0@openvdb@@UNodeStruct@?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@34@@std@@@std@@@std@@@std@@AEBVCoord@math@34@@Z ; openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> >::findCoord

; 1772 :     if (iter == mTable.end()) return mBackground;

	mov	rax, QWORD PTR iter$1[rsp]
	cmp	rax, QWORD PTR [rbx]
	jne	SHORT $LN5@operator
	lea	rax, QWORD PTR [rbx+16]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 496  :             });

	mov	rbx, QWORD PTR [rsp+56]
	mov	rsi, QWORD PTR [rsp+64]
	add	rsp, 32					; 00000020H
	pop	rdi
	ret	0
$LN5@operator:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 147  :         bool isChild() const { return child != nullptr; }

	mov	r9, QWORD PTR [rax+48]

; 1773 :     if (isChild(iter)) {

	test	r9, r9
	je	SHORT $LN6@operator
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	mov	ecx, DWORD PTR [rsi+8]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1775 :         return getChild(iter).getValueAndCache(xyz, acc);

	mov	r8, rdi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1005 :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	movq	xmm0, QWORD PTR [rsi]
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	and	ecx, -4096				; fffffffffffff000H
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1005 :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	andps	xmm0, XMMWORD PTR __xmm@fffff000fffff000fffff000fffff000
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1775 :         return getChild(iter).getValueAndCache(xyz, acc);

	mov	rdx, rsi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1005 :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	movq	QWORD PTR [rdi+560], xmm0
	mov	DWORD PTR [rdi+568], ecx

; 1006 :             mNodes.template get<Idx>() = const_cast<NodeT*>(node);

	mov	QWORD PTR [rdi+584], r9
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1775 :         return getChild(iter).getValueAndCache(xyz, acc);

	mov	rcx, QWORD PTR [rax+48]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 496  :             });

	mov	rbx, QWORD PTR [rsp+56]
	mov	rsi, QWORD PTR [rsp+64]
	add	rsp, 32					; 00000020H
	pop	rdi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 1775 :         return getChild(iter).getValueAndCache(xyz, acc);

	jmp	??$getValueAndCache@$$CBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@tree@v13_0@openvdb@@@?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@QEBAAEBGAEBVCoord@math@23@AEBV?$ValueAccessorImpl@V?$Tree@V?$RootNode@V?$InternalNode@V?$InternalNode@V?$LeafNode@G$02@tree@v13_0@openvdb@@$03@tree@v13_0@openvdb@@$04@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@@tree@v13_0@openvdb@@$00XU?$index_sequence@$0A@$00$01@34@@123@@Z ; openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5>::getValueAndCache<openvdb::v13_0::tree::ValueAccessorImpl<openvdb::v13_0::tree::Tree<openvdb::v13_0::tree::RootNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::InternalNode<openvdb::v13_0::tree::LeafNode<unsigned short,3>,4>,5> > >,1,void,openvdb::v13_0::index_sequence<0,1,2> > const >
$LN6@operator:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 496  :             });

	mov	rbx, QWORD PTR [rsp+56]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\RootNode.h

; 168  :     static const Tile&      getTile(const MapCIter& i) { return i->second.tile; }

	add	rax, 56					; 00000038H
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 496  :             });

	mov	rsi, QWORD PTR [rsp+64]
	add	rsp, 32					; 00000020H
	pop	rdi
	ret	0
??$?RU?$integral_constant@_K$02@std@@@<lambda_e4649fcf69ede42423c785e8d6f0e9d1>@@QEBAPEBGU?$integral_constant@_K$02@std@@@Z ENDP ; <lambda_e4649fcf69ede42423c785e8d6f0e9d1>::operator()<std::integral_constant<unsigned __int64,3> >
