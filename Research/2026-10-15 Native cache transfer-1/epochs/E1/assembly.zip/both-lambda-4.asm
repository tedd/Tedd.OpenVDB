??$?RU?$integral_constant@_K$0A@@std@@@<lambda_ca3903ac405762ed18e3c24717acdf32>@@QEBA_NU?$integral_constant@_K$0A@@std@@@Z PROC ; <lambda_ca3903ac405762ed18e3c24717acdf32>::operator()<std::integral_constant<unsigned __int64,0> >, COMDAT

; 1039 :             }, op);

$LN158:
	mov	QWORD PTR [rsp+16], rbx
	mov	QWORD PTR [rsp+24], rsi
	push	rdi
	sub	rsp, 32					; 00000020H

; 977  :                         this->insert(xyz, leaf);
; 978  :                         return true;
; 979  :                     }
; 980  :                 }
; 981  :             }
; 982  : #endif
; 983  :             return matches;
; 984  :         }
; 985  :     }
; 986  : 
; 987  : private:
; 988  :     /// @brief  Evaluate a function on each node until its returns value is not
; 989  :     ///   null or false.
; 990  :     /// @param op  The function to run
; 991  :     template <typename OpT>
; 992  :     OPENVDB_FORCE_INLINE auto evalFirstIndex(OpT&& op) const
; 993  :     {
; 994  :         OPENVDB_ASSERT(BaseT::mTree);
; 995  :         // Mutex lock the accessor. Does nothing if no mutex if in place
; 996  :         [[maybe_unused]] const auto lock = this->lock();
; 997  :         // Get the return type of the provided operation OpT
; 998  :         using IndexT = std::integral_constant<std::size_t, 0>;
; 999  :         using RetT = typename std::invoke_result<OpT, IndexT>::type;
; 1000 :         return openvdb::evalFirstIndex<0, NumCacheLevels+1>(op, RetT(NULL));
; 1001 :     }
; 1002 : 
; 1003 :     /// @brief  Evaluate a predicate on each index I from [0,Size] until it
; 1004 :     ///   returns true, then executes the provided op function on the resolved
; 1005 :     ///   node type. Helps in cases where std::get may be unecessarily invoked.
; 1006 :     /// @param pred The predicate to run on the node index
; 1007 :     /// @param op   The function to run on the node where the pred returns true
; 1008 :     template <typename PredT, typename OpT>
; 1009 :     OPENVDB_FORCE_INLINE auto evalFirstPred(PredT&& pred, OpT&& op) const
; 1010 :     {
; 1011 :         OPENVDB_ASSERT(BaseT::mTree);
; 1012 :         // Mutex lock the accessor. Does nothing if no mutex if in place
; 1013 :         [[maybe_unused]] const auto lock = this->lock();
; 1014 :         using RetT = typename std::invoke_result<OpT, RootNodeT*>::type;
; 1015 :         if constexpr(!std::is_same<RetT, void>::value) {
; 1016 :             return mNodes.evalFirstPred(pred, op, RetT(false));
; 1017 :         }
; 1018 :         else {
; 1019 :             return mNodes.evalFirstPred(pred, op);
; 1020 :         }
; 1021 :     }
; 1022 : 
; 1023 :     /// @brief  Helper alias to call this->evalFirstPred(), but with a default
; 1024 :     ///   predicate set to return true when the node at the given index is
; 1025 :     ///   cached
; 1026 :     /// @param xyz The coord to hash
; 1027 :     /// @param op  The function to run on the node where the pred returns true
; 1028 :     template <size_t Start = 0, typename OpT = void>
; 1029 :     OPENVDB_FORCE_INLINE auto evalFirstCached([[maybe_unused]] const Coord& xyz, OpT&& op) const
; 1030 :     {
; 1031 :         return this->evalFirstPred([&](const auto Idx) -> bool
; 1032 :             {
; 1033 :                 if constexpr(Idx < Start)                  return false;
; 1034 :                 else if constexpr(static_cast<ptrdiff_t>(Idx) > static_cast<ptrdiff_t>(NumCacheLevels) + 1)  return false;
; 1035 :                 else {
; 1036 :                     using NodeType = typename NodeLevelList::template Get<Idx>;
; 1037 :                     return this->isHashed<NodeType>(xyz);

	mov	rbx, QWORD PTR [rcx]
	mov	r8, QWORD PTR [rcx+8]

; 968  :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	ecx, DWORD PTR [r8]
	mov	r9d, ecx
	and	r9d, -8
	cmp	r9d, DWORD PTR [rbx+536]
	jne	SHORT $LN7@operator
	mov	eax, DWORD PTR [r8+4]
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+540]
	jne	SHORT $LN7@operator
	mov	eax, DWORD PTR [r8+8]
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+544]
	jne	SHORT $LN7@operator
	mov	sil, 1
$LN5@operator:

; 977  :                         this->insert(xyz, leaf);
; 978  :                         return true;
; 979  :                     }
; 980  :                 }
; 981  :             }
; 982  : #endif
; 983  :             return matches;
; 984  :         }
; 985  :     }
; 986  : 
; 987  : private:
; 988  :     /// @brief  Evaluate a function on each node until its returns value is not
; 989  :     ///   null or false.
; 990  :     /// @param op  The function to run
; 991  :     template <typename OpT>
; 992  :     OPENVDB_FORCE_INLINE auto evalFirstIndex(OpT&& op) const
; 993  :     {
; 994  :         OPENVDB_ASSERT(BaseT::mTree);
; 995  :         // Mutex lock the accessor. Does nothing if no mutex if in place
; 996  :         [[maybe_unused]] const auto lock = this->lock();
; 997  :         // Get the return type of the provided operation OpT
; 998  :         using IndexT = std::integral_constant<std::size_t, 0>;
; 999  :         using RetT = typename std::invoke_result<OpT, IndexT>::type;
; 1000 :         return openvdb::evalFirstIndex<0, NumCacheLevels+1>(op, RetT(NULL));
; 1001 :     }
; 1002 : 
; 1003 :     /// @brief  Evaluate a predicate on each index I from [0,Size] until it
; 1004 :     ///   returns true, then executes the provided op function on the resolved
; 1005 :     ///   node type. Helps in cases where std::get may be unecessarily invoked.
; 1006 :     /// @param pred The predicate to run on the node index
; 1007 :     /// @param op   The function to run on the node where the pred returns true
; 1008 :     template <typename PredT, typename OpT>
; 1009 :     OPENVDB_FORCE_INLINE auto evalFirstPred(PredT&& pred, OpT&& op) const
; 1010 :     {
; 1011 :         OPENVDB_ASSERT(BaseT::mTree);
; 1012 :         // Mutex lock the accessor. Does nothing if no mutex if in place
; 1013 :         [[maybe_unused]] const auto lock = this->lock();
; 1014 :         using RetT = typename std::invoke_result<OpT, RootNodeT*>::type;
; 1015 :         if constexpr(!std::is_same<RetT, void>::value) {
; 1016 :             return mNodes.evalFirstPred(pred, op, RetT(false));
; 1017 :         }
; 1018 :         else {
; 1019 :             return mNodes.evalFirstPred(pred, op);
; 1020 :         }
; 1021 :     }
; 1022 : 
; 1023 :     /// @brief  Helper alias to call this->evalFirstPred(), but with a default
; 1024 :     ///   predicate set to return true when the node at the given index is
; 1025 :     ///   cached
; 1026 :     /// @param xyz The coord to hash
; 1027 :     /// @param op  The function to run on the node where the pred returns true
; 1028 :     template <size_t Start = 0, typename OpT = void>
; 1029 :     OPENVDB_FORCE_INLINE auto evalFirstCached([[maybe_unused]] const Coord& xyz, OpT&& op) const
; 1030 :     {
; 1031 :         return this->evalFirstPred([&](const auto Idx) -> bool
; 1032 :             {
; 1033 :                 if constexpr(Idx < Start)                  return false;
; 1034 :                 else if constexpr(static_cast<ptrdiff_t>(Idx) > static_cast<ptrdiff_t>(NumCacheLevels) + 1)  return false;
; 1035 :                 else {
; 1036 :                     using NodeType = typename NodeLevelList::template Get<Idx>;
; 1037 :                     return this->isHashed<NodeType>(xyz);

	movzx	eax, sil

; 1039 :             }, op);

	mov	rbx, QWORD PTR [rsp+56]
	mov	rsi, QWORD PTR [rsp+64]
	add	rsp, 32					; 00000020H
	pop	rdi
	ret	0
$LN7@operator:

; 1050 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	r10d, DWORD PTR [r8+8]
	and	ecx, 24
	mov	r11d, DWORD PTR [r8+4]

; 968  :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	xor	sil, sil

; 1050 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	eax, r11d
	and	eax, 24
	lea	edx, DWORD PTR [rcx+rcx]
	mov	ecx, r10d
	shr	rcx, 2
	and	ecx, 6
	or	rcx, rax
	shr	rcx, 1
	or	rcx, rdx

; 974  :                     const auto leaf = mSecondaryLeaves[secondarySlot(xyz)];

	mov	rdi, QWORD PTR [rbx+rcx*8+24]

; 975  :                     // Full origin equality rejects collisions, including signed coordinates.
; 976  :                     if (leaf && leaf->origin() == (xyz & ~Coord::ValueType(NodeT::DIM-1))) {

	test	rdi, rdi
	je	SHORT $LN5@operator
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rdi+80], r9d
	jne	SHORT $LN5@operator

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	and	r11d, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rdi+84], r11d
	jne	SHORT $LN5@operator

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	and	r10d, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rdi+88], r10d
	jne	SHORT $LN5@operator
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 945  :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	mov	DWORD PTR [rbx+536], r9d
	mov	DWORD PTR [rbx+540], r11d
	mov	DWORD PTR [rbx+544], r10d

; 946  :             mNodes.template get<Idx>() = const_cast<NodeT*>(node);

	mov	QWORD PTR [rbx+600], rdi

; 1050 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	eax, DWORD PTR [r8+4]
	mov	ecx, DWORD PTR [r8+8]
	and	eax, 24
	shr	rcx, 2
	and	ecx, 6
	or	rcx, rax
	mov	eax, DWORD PTR [r8]
	and	eax, 24
	shr	rcx, 1
	add	eax, eax
	or	rcx, rax

; 949  :                 mSecondaryLeaves[secondarySlot(xyz)] = node;

	mov	QWORD PTR [rbx+rcx*8+24], rdi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafBuffer.h

; 370  :     if (mData == nullptr) {

	mov	rax, QWORD PTR [rdi]
	test	rax, rax
	jne	SHORT $LN145@operator

; 371  :         LeafBuffer* self = const_cast<LeafBuffer*>(this);
; 372  : #ifdef OPENVDB_USE_DELAYED_LOADING
; 373  :         // This lock will be contended at most once.
; 374  :         tbb::spin_mutex::scoped_lock lock(self->mMutex);
; 375  : #endif
; 376  :         if (mData == nullptr) self->mData = new ValueType[SIZE];

	mov	ecx, 1024				; 00000400H
	call	??_U@YAPEAX_K@Z				; operator new[]
	mov	QWORD PTR [rdi], rax
$LN145@operator:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 1039 :             }, op);

	mov	rsi, QWORD PTR [rsp+64]

; 952  :                 LeafCacheT::setBuffer(node->buffer().data());

	mov	QWORD PTR [rbx+16], rax

; 977  :                         this->insert(xyz, leaf);
; 978  :                         return true;
; 979  :                     }
; 980  :                 }
; 981  :             }
; 982  : #endif
; 983  :             return matches;
; 984  :         }
; 985  :     }
; 986  : 
; 987  : private:
; 988  :     /// @brief  Evaluate a function on each node until its returns value is not
; 989  :     ///   null or false.
; 990  :     /// @param op  The function to run
; 991  :     template <typename OpT>
; 992  :     OPENVDB_FORCE_INLINE auto evalFirstIndex(OpT&& op) const
; 993  :     {
; 994  :         OPENVDB_ASSERT(BaseT::mTree);
; 995  :         // Mutex lock the accessor. Does nothing if no mutex if in place
; 996  :         [[maybe_unused]] const auto lock = this->lock();
; 997  :         // Get the return type of the provided operation OpT
; 998  :         using IndexT = std::integral_constant<std::size_t, 0>;
; 999  :         using RetT = typename std::invoke_result<OpT, IndexT>::type;
; 1000 :         return openvdb::evalFirstIndex<0, NumCacheLevels+1>(op, RetT(NULL));
; 1001 :     }
; 1002 : 
; 1003 :     /// @brief  Evaluate a predicate on each index I from [0,Size] until it
; 1004 :     ///   returns true, then executes the provided op function on the resolved
; 1005 :     ///   node type. Helps in cases where std::get may be unecessarily invoked.
; 1006 :     /// @param pred The predicate to run on the node index
; 1007 :     /// @param op   The function to run on the node where the pred returns true
; 1008 :     template <typename PredT, typename OpT>
; 1009 :     OPENVDB_FORCE_INLINE auto evalFirstPred(PredT&& pred, OpT&& op) const
; 1010 :     {
; 1011 :         OPENVDB_ASSERT(BaseT::mTree);
; 1012 :         // Mutex lock the accessor. Does nothing if no mutex if in place
; 1013 :         [[maybe_unused]] const auto lock = this->lock();
; 1014 :         using RetT = typename std::invoke_result<OpT, RootNodeT*>::type;
; 1015 :         if constexpr(!std::is_same<RetT, void>::value) {
; 1016 :             return mNodes.evalFirstPred(pred, op, RetT(false));
; 1017 :         }
; 1018 :         else {
; 1019 :             return mNodes.evalFirstPred(pred, op);
; 1020 :         }
; 1021 :     }
; 1022 : 
; 1023 :     /// @brief  Helper alias to call this->evalFirstPred(), but with a default
; 1024 :     ///   predicate set to return true when the node at the given index is
; 1025 :     ///   cached
; 1026 :     /// @param xyz The coord to hash
; 1027 :     /// @param op  The function to run on the node where the pred returns true
; 1028 :     template <size_t Start = 0, typename OpT = void>
; 1029 :     OPENVDB_FORCE_INLINE auto evalFirstCached([[maybe_unused]] const Coord& xyz, OpT&& op) const
; 1030 :     {
; 1031 :         return this->evalFirstPred([&](const auto Idx) -> bool
; 1032 :             {
; 1033 :                 if constexpr(Idx < Start)                  return false;
; 1034 :                 else if constexpr(static_cast<ptrdiff_t>(Idx) > static_cast<ptrdiff_t>(NumCacheLevels) + 1)  return false;
; 1035 :                 else {
; 1036 :                     using NodeType = typename NodeLevelList::template Get<Idx>;
; 1037 :                     return this->isHashed<NodeType>(xyz);

	mov	al, 1

; 1039 :             }, op);

	mov	rbx, QWORD PTR [rsp+56]
	add	rsp, 32					; 00000020H
	pop	rdi
	ret	0
??$?RU?$integral_constant@_K$0A@@std@@@<lambda_ca3903ac405762ed18e3c24717acdf32>@@QEBA_NU?$integral_constant@_K$0A@@std@@@Z ENDP ; <lambda_ca3903ac405762ed18e3c24717acdf32>::operator()<std::integral_constant<unsigned __int64,0> >
