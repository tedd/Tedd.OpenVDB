??$?RU?$integral_constant@_K$0A@@std@@@<lambda_5bb52e0367d4c99b6fde692a40776041>@@QEBAPEBGU?$integral_constant@_K$0A@@std@@@Z PROC ; <lambda_5bb52e0367d4c99b6fde692a40776041>::operator()<std::integral_constant<unsigned __int64,0> >, COMDAT

; 475  :             });

$LN176:
	mov	QWORD PTR [rsp+16], rbx
	mov	QWORD PTR [rsp+24], rsi
	push	rdi
	sub	rsp, 32					; 00000020H

; 465  :                 if (!this->isHashed<NodeType>(xyz)) return nullptr;

	mov	r8, QWORD PTR [rcx+8]
	mov	rsi, rcx
	mov	rbx, QWORD PTR [rcx]

; 968  :             const bool matches = (xyz[0] & ~Coord::ValueType(NodeT::DIM-1)) == mKeys[Idx][0]

	mov	edx, DWORD PTR [r8]
	mov	r9d, edx
	and	r9d, -8
	cmp	r9d, DWORD PTR [rbx+536]
	jne	SHORT $LN8@operator
	mov	eax, DWORD PTR [r8+4]
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+540]
	jne	SHORT $LN8@operator
	mov	eax, DWORD PTR [r8+8]
	and	eax, -8
	cmp	eax, DWORD PTR [rbx+544]
	je	$LN2@operator
$LN8@operator:

; 1050 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	r10d, DWORD PTR [r8+8]
	and	edx, 24
	mov	r11d, DWORD PTR [r8+4]
	add	edx, edx
	mov	eax, r11d
	mov	ecx, r10d
	shr	rcx, 2
	and	eax, 24
	and	ecx, 6
	or	rcx, rax
	shr	rcx, 1
	or	rcx, rdx

; 974  :                     const auto leaf = mSecondaryLeaves[secondarySlot(xyz)];

	mov	rdi, QWORD PTR [rbx+rcx*8+24]

; 975  :                     // Full origin equality rejects collisions, including signed coordinates.
; 976  :                     if (leaf && leaf->origin() == (xyz & ~Coord::ValueType(NodeT::DIM-1))) {

	test	rdi, rdi
	je	$LN166@operator
; File D:\source\openvdb\openvdb\openvdb\math\Coord.h

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rdi+80], r9d
	jne	$LN166@operator

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	and	r11d, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rdi+84], r11d
	jne	$LN166@operator

; 126  :     Coord  operator&  (Int32 n) const { return Coord(mVec[0] & n, mVec[1] & n, mVec[2] & n); }

	and	r10d, -8

; 152  :         return (mVec[0] == rhs.mVec[0] && mVec[1] == rhs.mVec[1] && mVec[2] == rhs.mVec[2]);

	cmp	DWORD PTR [rdi+88], r10d
	jne	$LN166@operator
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 945  :             mKeys[Idx] = xyz & ~(NodeT::DIM-1);

	mov	DWORD PTR [rbx+536], r9d
	mov	DWORD PTR [rbx+540], r11d
	mov	DWORD PTR [rbx+544], r10d

; 946  :             mNodes.template get<Idx>() = const_cast<NodeT*>(node);

	mov	QWORD PTR [rbx+600], rdi

; 1050 :         return (((uint32_t(xyz[0]) >> shift) & 3) << 4)

	mov	eax, DWORD PTR [r8+4]
	mov	ecx, DWORD PTR [r8+8]
	and	eax, 24
	shr	rcx, 2
	and	ecx, 6
	or	rcx, rax
	mov	eax, DWORD PTR [r8]
	and	eax, 24
	shr	rcx, 1
	add	eax, eax
	or	rcx, rax

; 949  :                 mSecondaryLeaves[secondarySlot(xyz)] = node;

	mov	QWORD PTR [rbx+rcx*8+24], rdi
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafBuffer.h

; 370  :     if (mData == nullptr) {

	mov	rax, QWORD PTR [rdi]
	test	rax, rax
	jne	SHORT $LN163@operator

; 371  :         LeafBuffer* self = const_cast<LeafBuffer*>(this);
; 372  : #ifdef OPENVDB_USE_DELAYED_LOADING
; 373  :         // This lock will be contended at most once.
; 374  :         tbb::spin_mutex::scoped_lock lock(self->mMutex);
; 375  : #endif
; 376  :         if (mData == nullptr) self->mData = new ValueType[SIZE];

	mov	ecx, 1024				; 00000400H
	call	??_U@YAPEAX_K@Z				; operator new[]
	mov	QWORD PTR [rdi], rax
$LN163@operator:
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 952  :                 LeafCacheT::setBuffer(node->buffer().data());

	mov	QWORD PTR [rbx+16], rax
$LN2@operator:

; 468  :                     return &(LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)]);

	mov	rcx, QWORD PTR [rsi+8]
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\LeafNode.h

; 1072 :     return ((xyz[0] & (DIM-1u)) << 2*Log2Dim)

	mov	edx, DWORD PTR [rcx]
	mov	eax, DWORD PTR [rcx+4]
	and	edx, 7
	and	eax, 7
	shl	edx, 3
	or	edx, eax
	mov	eax, DWORD PTR [rcx+8]
	and	eax, 7
	shl	edx, 3
	or	edx, eax
; File D:\Workspaces\AI\openvdb-native-cache-transfer-20261015\overlay\openvdb\tree\ValueAccessor.h

; 468  :                     return &(LeafCacheT::buffer()[LeafNodeT::coordToOffset(xyz)]);

	mov	rax, QWORD PTR [rsi]
	mov	rcx, QWORD PTR [rax+16]
	lea	rax, QWORD PTR [rcx+rdx*2]

; 475  :             });

	mov	rbx, QWORD PTR [rsp+56]
	mov	rsi, QWORD PTR [rsp+64]
	add	rsp, 32					; 00000020H
	pop	rdi
	ret	0
$LN166@operator:
	mov	rbx, QWORD PTR [rsp+56]
	xor	eax, eax
	mov	rsi, QWORD PTR [rsp+64]
	add	rsp, 32					; 00000020H
	pop	rdi
	ret	0
??$?RU?$integral_constant@_K$0A@@std@@@<lambda_5bb52e0367d4c99b6fde692a40776041>@@QEBAPEBGU?$integral_constant@_K$0A@@std@@@Z ENDP ; <lambda_5bb52e0367d4c99b6fde692a40776041>::operator()<std::integral_constant<unsigned __int64,0> >
